
let map, markers = [], stations = [];

function riskClass(level){
  if(level==="CRITICAL") return "#ff6577";
  if(level==="HIGH") return "#f4ca64";
  if(level==="MODERATE") return "#53e0ff";
  return "#50e3a4";
}
async function getJSON(url, options){ const r=await fetch(url,options); if(!r.ok) throw new Error(await r.text()); return r.json(); }

function initMap(){
  map=L.map('map',{zoomControl:true}).setView([30.05,79.25],7);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:18,attribution:'© OpenStreetMap'}).addTo(map);
}

function drawMarkers(){
  markers.forEach(m=>m.remove()); markers=[];
  stations.forEach(s=>{
    const c=riskClass(s.risk_level);
    const m=L.circleMarker([s.lat,s.lon],{radius:8,weight:2,color:c,fillColor:c,fillOpacity:.75})
      .addTo(map)
      .bindPopup(`<b>${s.station}</b><br>${s.district}<br>Risk: <b>${s.risk_level}</b><br>1h: ${s.rainfall_1h} mm<br>24h: ${s.rainfall_24h} mm`);
    markers.push(m);
  });
}

async function loadSummary(){
  const x=await getJSON('/api/summary');
  document.getElementById('stations').textContent=x.stations;
  document.getElementById('critical').textContent=x.critical;
  document.getElementById('high').textContent=x.high;
  document.getElementById('lastData').textContent='Latest: '+x.latest_data;
  const level=x.critical>0?'CRITICAL':x.high>0?'HIGH':x.moderate>0?'MODERATE':'LOW';
  document.getElementById('overallLevel').textContent=level;
}

async function loadMetrics(){
  const x=await getJSON('/api/metrics');
  document.getElementById('modelState').textContent='READY';
  document.getElementById('integrity').innerHTML=
    `<strong>ML:</strong> ${x.model_type}<br>`+
    `<strong>Rows:</strong> ${x.training_rows.toLocaleString()}<br>`+
    `<strong>Stations:</strong> ${x.stations}<br>`+
    `<strong>Training:</strong> ${x.training_period[0]} → ${x.training_period[1]}<br>`+
    `<strong>Features:</strong> 1h, 3h, 6h, 12h, 24h, 72h rainfall<br><br>`+
    `⚠️ ${x.note}`;
}

async function loadStations(){
  const x=await getJSON('/api/stations'); stations=x.stations;
  const sel=document.getElementById('stationSelect');
  sel.innerHTML=stations.map((s,i)=>`<option value="${s.station}" ${i===0?'selected':''}>${s.station} — ${s.district}</option>`).join('');
  drawMarkers();
  await loadStation();
}

async function loadStation(){
  const name=document.getElementById('stationSelect').value;
  if(!name) return;
  const x=await getJSON('/api/station/'+encodeURIComponent(name));
  document.getElementById('stationName').textContent=x.station;
  document.getElementById('district').textContent=x.district;
  document.getElementById('riskLevel').textContent=x.risk.risk_level;
  document.getElementById('riskLevel').style.color=riskClass(x.risk.risk_level);
  document.getElementById('riskScore').textContent=x.risk.risk_score;
  document.getElementById('r1').textContent=x.rainfall["1"];
  document.getElementById('r3').textContent=x.rainfall["3"];
  document.getElementById('r6').textContent=x.rainfall["6"];
  document.getElementById('r24').textContent=x.rainfall["24"];
  document.getElementById('r72').textContent=x.rainfall["72"];
  document.getElementById('ml').textContent=x.risk.ml_anomaly_score;
  document.getElementById('pressure').textContent=x.risk.rainfall_pressure;
  document.getElementById('action').textContent=x.risk.action;
}

async function refreshAll(){
  try{ await loadSummary(); await loadMetrics(); await loadStations(); }
  catch(e){ console.error(e); alert('API error: '+e.message); }
}
window.addEventListener('load',async()=>{initMap(); await refreshAll();});
